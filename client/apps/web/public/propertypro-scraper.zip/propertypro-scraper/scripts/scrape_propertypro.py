#!/usr/bin/env python3
"""
scrape_propertypro.py

Scrapes propertypro.ng for rental price ranges and common amenities across
a list of Lagos (or other Nigerian) locations, for 1/2/3/4+ bedroom flats.

INPUT
-----
A JSON file that is a flat list of strings, each one of:
  "State"                              e.g. "Lagos"
  "Area , State"                       e.g. "Ikeja , Lagos"
  "Sub Location , Area , State"        e.g. "Maryland , Ikeja , Lagos"

Only 3-part (Sub Location, Area, State) and 2-part (Area, State) entries are
scraped as distinct search targets. Bare state-level rows are skipped
(too broad to be useful and duplicate what the area-level rows cover).

OUTPUT
------
A CSV with one row per (location, bedroom_count) combination:
  state, area, sub_location, bedrooms, listing_count,
  min_price_ngn, max_price_ngn, avg_price_ngn,
  top_amenities, sample_urls, url, scraped_at, status

Progress is checkpointed to the same CSV as it goes, so the script can be
killed and re-run safely -- it will skip rows already present in the output
file unless --overwrite is passed.

USAGE
-----
  pip install requests beautifulsoup4 --break-system-packages

  # Dry run on a handful of locations first (recommended!):
  python scrape_propertypro.py --input locations.json --output results.csv --limit 5

  # Full run:
  python scrape_propertypro.py --input locations.json --output results.csv

  # Only certain bedroom counts:
  python scrape_propertypro.py --input locations.json --output results.csv --beds 1 2

  # Skip amenity scraping (much faster, price ranges only):
  python scrape_propertypro.py --input locations.json --output results.csv --no-amenities

NOTES ON RATE LIMITING
-----------------------
This makes 1 request per (location, bedroom) for prices, plus a handful more
per location for amenity sampling. With ~280 locations x 4 bedroom types
that's 1000+ requests. Be a good citizen:
  - Default delay is 2-4s (randomized) between requests.
  - Respects a simple retry-with-backoff on 429/5xx.
  - Use --limit while testing. Use --beds to narrow scope for a first pass.
  - Consider running overnight / in batches rather than all at once.
"""

import argparse
import csv
import json
import os
import random
import re
import sys
import time
from collections import Counter
from datetime import datetime, timezone

import requests
from bs4 import BeautifulSoup

BASE = "https://propertypro.ng"
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}

BEDROOM_LABELS = {1: "1-bedroom", 2: "2-bedroom", 3: "3-bedroom", 4: "4-bedroom"}

PRICE_RE = re.compile(r"₦\s?([\d,]+)")
AVG_SENTENCE_RE = re.compile(r"average price[^₦]*₦\s?([\d,]+)", re.I)
MAX_SENTENCE_RE = re.compile(r"most expensive[^₦]*₦\s?([\d,]+)", re.I)
MIN_SENTENCE_RE = re.compile(r"cheapest[^₦]*₦\s?([\d,]+)", re.I)
COUNT_RE = re.compile(r"total of\s+([\d,]+)", re.I)


def slugify(text):
    """Turn 'Obafemi Awolowo Way' -> 'obafemi-awolowo-way', matching propertypro's URL scheme."""
    text = text.strip().lower()
    text = re.sub(r"[()]", "", text)
    text = re.sub(r"[^a-z0-9\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text)
    return text.strip("-")


def parse_locations(path):
    """Parse the flat 'Area, Sub Location, State' JSON list into structured rows.

    Returns a list of dicts: {state, area, sub_location} for every 2-part or
    3-part entry. Bare 1-part (state-only) entries are skipped.
    """
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    rows = []
    for entry in raw:
        parts = [p.strip() for p in entry.split(",")]
        if len(parts) == 1:
            continue  # bare state, skip
        elif len(parts) == 2:
            area, state = parts
            rows.append({"state": state, "area": area, "sub_location": ""})
        elif len(parts) >= 3:
            sub_location, area, state = parts[0], parts[1], parts[-1]
            rows.append({"state": state, "area": area, "sub_location": sub_location})
    return rows


def build_url(state, area, sub_location, bedrooms):
    parts = [BASE, "property-for-rent", "flat-apartment", "in", slugify(state), slugify(area)]
    if sub_location:
        parts.append(slugify(sub_location))
    parts.append(BEDROOM_LABELS[bedrooms])
    return "/".join(parts)


def fetch(session, url, max_retries=3):
    for attempt in range(1, max_retries + 1):
        try:
            resp = session.get(url, headers=HEADERS, timeout=20)
            if resp.status_code == 200:
                return resp
            if resp.status_code == 404:
                return resp  # location/bedroom combo just doesn't exist
            if resp.status_code in (429, 500, 502, 503, 504):
                wait = attempt * 5
                time.sleep(wait)
                continue
            return resp
        except requests.RequestException:
            time.sleep(attempt * 5)
    return None


def parse_price_summary(html_text):
    """Extract min/max/avg price and listing count from a category page's text."""
    text = re.sub(r"\s+", " ", html_text)
    avg_m = AVG_SENTENCE_RE.search(text)
    max_m = MAX_SENTENCE_RE.search(text)
    min_m = MIN_SENTENCE_RE.search(text)
    count_m = COUNT_RE.search(text)

    def to_int(m):
        return int(m.group(1).replace(",", "")) if m else None

    return {
        "avg_price": to_int(avg_m),
        "max_price": to_int(max_m),
        "min_price": to_int(min_m),
        "listing_count": to_int(count_m),
    }


def extract_listing_links(soup, limit=5):
    links = []
    for a in soup.select("a[href]"):
        href = a["href"]
        if "/property/" in href and href not in links:
            if href.startswith("/"):
                href = BASE + href
            links.append(href)
        if len(links) >= limit:
            break
    return links


AMENITY_KEYWORDS = [
    "swimming pool", "gym", "fitness", "cctv", "security", "24 hours power",
    "24hrs power", "prepaid meter", "furnished", "serviced", "fitted kitchen",
    "pop ceiling", "wardrobe", "parking", "elevator", "lift", "balcony",
    "estate", "gated", "generator", "borehole", "water treatment",
    "playground", "children's play", "car park", "ensuite", "en-suite",
    "ac", "air condition", "solar",
]


def extract_amenities(soup):
    text = soup.get_text(" ", strip=True).lower()
    found = [kw for kw in AMENITY_KEYWORDS if kw in text]
    return found


def scrape_amenities_for_location(session, category_url, sample_size, delay_range):
    """Visit the category page, grab a few individual listing links, and tally
    amenity keyword mentions across them."""
    resp = fetch(session, category_url)
    if not resp or resp.status_code != 200:
        return []
    soup = BeautifulSoup(resp.text, "html.parser")
    links = extract_listing_links(soup, limit=sample_size)

    tally = Counter()
    for link in links:
        time.sleep(random.uniform(*delay_range))
        r = fetch(session, link)
        if not r or r.status_code != 200:
            continue
        s = BeautifulSoup(r.text, "html.parser")
        for kw in extract_amenities(s):
            tally[kw] += 1

    top = [kw for kw, _ in tally.most_common(8)]
    return top


def load_done_keys(output_path):
    done = set()
    if os.path.exists(output_path):
        with open(output_path, "r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                done.add((row["state"], row["area"], row["sub_location"], row["bedrooms"]))
    return done


FIELDNAMES = [
    "state", "area", "sub_location", "bedrooms", "listing_count",
    "min_price_ngn", "max_price_ngn", "avg_price_ngn",
    "top_amenities", "url", "scraped_at", "status",
]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", required=True, help="Path to the locations JSON file")
    ap.add_argument("--output", required=True, help="Path to the output CSV (also used as checkpoint)")
    ap.add_argument("--beds", nargs="+", type=int, default=[1, 2, 3, 4], help="Bedroom counts to scrape (default: 1 2 3 4)")
    ap.add_argument("--limit", type=int, default=None, help="Only process the first N locations (for testing)")
    ap.add_argument("--no-amenities", action="store_true", help="Skip amenity sampling (faster)")
    ap.add_argument("--amenity-sample-size", type=int, default=4, help="How many listing pages to sample per location for amenities")
    ap.add_argument("--min-delay", type=float, default=2.0)
    ap.add_argument("--max-delay", type=float, default=4.0)
    ap.add_argument("--overwrite", action="store_true", help="Ignore existing checkpoint rows and re-scrape everything")
    args = ap.parse_args()

    locations = parse_locations(args.input)
    if args.limit:
        locations = locations[: args.limit]

    done_keys = set() if args.overwrite else load_done_keys(args.output)
    write_header = not os.path.exists(args.output) or args.overwrite
    mode = "w" if args.overwrite or not os.path.exists(args.output) else "a"

    session = requests.Session()
    delay_range = (args.min_delay, args.max_delay)

    total_jobs = len(locations) * len(args.beds)
    done_count = 0

    with open(args.output, mode, encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        if write_header:
            writer.writeheader()

        for loc in locations:
            for beds in args.beds:
                key = (loc["state"], loc["area"], loc["sub_location"], str(beds))
                done_count += 1
                if key in done_keys:
                    continue

                url = build_url(loc["state"], loc["area"], loc["sub_location"], beds)
                label = f"{loc['sub_location'] or loc['area']}, {loc['area']}, {loc['state']} [{beds}bed]"
                print(f"[{done_count}/{total_jobs}] {label} -> {url}", file=sys.stderr)

                resp = fetch(session, url)
                row = {
                    "state": loc["state"], "area": loc["area"], "sub_location": loc["sub_location"],
                    "bedrooms": beds, "listing_count": "", "min_price_ngn": "", "max_price_ngn": "",
                    "avg_price_ngn": "", "top_amenities": "", "url": url,
                    "scraped_at": datetime.now(timezone.utc).isoformat(), "status": "",
                }

                if resp is None:
                    row["status"] = "error_no_response"
                elif resp.status_code == 404:
                    row["status"] = "not_found"
                elif resp.status_code != 200:
                    row["status"] = f"http_{resp.status_code}"
                else:
                    summary = parse_price_summary(resp.text)
                    row["listing_count"] = summary["listing_count"] or ""
                    row["min_price_ngn"] = summary["min_price"] or ""
                    row["max_price_ngn"] = summary["max_price"] or ""
                    row["avg_price_ngn"] = summary["avg_price"] or ""
                    row["status"] = "ok" if summary["min_price"] else "ok_no_price_data"

                    if not args.no_amenities and row["status"] == "ok":
                        amenities = scrape_amenities_for_location(
                            session, url, args.amenity_sample_size, delay_range
                        )
                        row["top_amenities"] = "; ".join(amenities)

                writer.writerow(row)
                f.flush()
                time.sleep(random.uniform(*delay_range))

    print(f"Done. Results in {args.output}", file=sys.stderr)


if __name__ == "__main__":
    main()
