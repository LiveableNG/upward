---
name: propertypro-lagos-rent-scraper
description: Scrapes propertypro.ng for rental price ranges (min/max/average) and common amenities for 1, 2, 3, and 4-bedroom flats/apartments across a list of Nigerian (e.g. Lagos) locations supplied as a JSON file of "Area, Sub Location, State" strings. Use this whenever the user wants Lagos/Nigeria rental market data, budget ranges by area, or amenity comparisons pulled from propertypro.ng, or asks to run/update/extend the propertypro scraper.
---

# PropertyPro.ng Rent Scraper

Scrapes propertypro.ng rental category pages to build a spreadsheet of, for
each location and bedroom count: minimum price, maximum price, average
price, number of listings, and a sample of commonly-mentioned amenities.

## Important: this needs real internet access

This skill fetches live pages from `propertypro.ng`. It will NOT work in a
sandboxed environment whose network is restricted to package registries
(pypi/npm/github/etc.) — check whether outbound HTTPS to propertypro.ng is
actually reachable before running the full job. If it isn't, tell the user
and suggest running it in Claude Code, Cowork, or their own machine instead.

## Input format

A JSON file that's a flat list of strings, each one of:
- `"State"` (e.g. `"Lagos"`) — skipped, too broad
- `"Area , State"` (e.g. `"Ikeja , Lagos"`) — scraped at the Area level
- `"Sub Location , Area , State"` (e.g. `"Maryland , Ikeja , Lagos"`) — scraped at the Sub Location level

## Workflow

1. **Save the user's location JSON** to a file (e.g. `locations.json`).
2. **Install dependencies**: `pip install requests beautifulsoup4 --break-system-packages`
3. **Always test on a small slice first.** With ~280 locations x 4 bedroom
   counts this is 1000+ requests — never run the full job blind.
   ```
   python scripts/scrape_propertypro.py --input locations.json --output test.csv --limit 5
   ```
   Open `test.csv` and sanity-check a couple of rows against the live site
   before scaling up.
4. **Run the full job.** Because the script checkpoints to the output CSV
   as it goes (skipping rows already present), it's safe to stop and resume:
   ```
   python scripts/scrape_propertypro.py --input locations.json --output results.csv
   ```
   Useful flags:
   - `--beds 1 2 3 4` — restrict which bedroom counts to scrape
   - `--no-amenities` — price ranges only, much faster (skips per-listing sampling)
   - `--amenity-sample-size 4` — how many individual listings to open per location to tally amenities
   - `--min-delay` / `--max-delay` — politeness delay between requests (default 2-4s)
   - `--overwrite` — ignore the checkpoint and rescrape everything
5. **Convert the CSV to whatever the user asked for** (spreadsheet, summary
   table, chart) once scraping is done. Use the xlsx skill if they want an
   Excel file.

## How "4+ bedroom" is handled

propertypro's URL scheme only has clean per-count pages (`1-bedroom`,
`2-bedroom`, `3-bedroom`, `4-bedroom`, ...). This skill's default `--beds 1 2 3 4`
treats the `4-bedroom` page as the "4+" proxy. If the user wants 5+/6+ bedroom
data included too, add `--beds 1 2 3 4 5 6` and merge those rows into a
single "4+" bucket afterward (min of the mins, max of the maxes) when
presenting results.

## Output columns

`state, area, sub_location, bedrooms, listing_count, min_price_ngn,
max_price_ngn, avg_price_ngn, top_amenities, url, scraped_at, status`

`status` will be one of: `ok`, `ok_no_price_data` (page loaded but no
listings/price text found — usually means zero inventory for that
combination), `not_found` (404 — slug likely doesn't match propertypro's
naming for that sub-location), `http_XXX`, or `error_no_response`.

## Known limitations / things to sanity check

- **Slug mismatches**: propertypro slugs are usually just lowercased,
  hyphenated versions of the area name, but not always — check a handful of
  `not_found` rows manually on the live site. Some sub-locations may only
  exist as filters on the parent Area's page rather than having their own URL.
- **Amenities are approximate**: they're pulled by keyword-matching the text
  of a small sample of individual listing pages per location, not a
  structured "amenities" field — treat `top_amenities` as indicative, not
  exhaustive.
- **Prices are in Nigerian Naira (₦)** and are typically annual rent figures
  unless the URL path is short-let.
- Respect the site — keep delays on, don't parallelize requests, and don't
  scrape more frequently than needed for the user's purpose.
